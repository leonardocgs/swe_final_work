import java.util.List;

public class SaiCommand implements  Command{

    @Override
    public String execute(List<String> parametros) {
            return null;
    }
}
