package domain.entity;

public interface Observador{
  public void notificarReserva();
}